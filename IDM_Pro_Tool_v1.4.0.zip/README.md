<p align="right">
  <strong>English</strong> | <a href="README.zh.md">简体中文</a>
</p>

<p align="center">
  <img src="app_icon.png" alt="IDM Pro Tool Logo" width="128" height="128">
</p>

<h1 align="center">IDM Pro Tool</h1>

<p align="center">
  <strong>Feature-Rich Native C# Activation & Lifecycle State Maintenance Toolkit for Internet Download Manager</strong>
</p>

<p align="center">
  <a href="https://github.com/angusdevgo/IDM_Pro_Tool/stargazers"><img src="https://img.shields.io/github/stars/angusdevgo/IDM_Pro_Tool?style=for-the-badge&logo=github&color=blue" alt="GitHub Stars"></a>
  <a href="https://github.com/angusdevgo/IDM_Pro_Tool/releases"><img src="https://img.shields.io/github/v/release/angusdevgo/IDM_Pro_Tool?style=for-the-badge&logo=github&color=brightgreen" alt="Latest Release"></a>
  <a href="https://github.com/angusdevgo/IDM_Pro_Tool/blob/main/LICENSE"><img src="https://img.shields.io/badge/License-GPLv3-blue.svg?style=for-the-badge" alt="License"></a>
  <img src="https://img.shields.io/badge/Platform-Windows-0078D6?style=for-the-badge&logo=windows" alt="Windows Platform">
  <img src="https://img.shields.io/badge/.NET%20Framework-4.x%20(Native)-purple?style=for-the-badge&logo=dotnet" alt=".NET Framework 4.x">
  <img src="https://img.shields.io/badge/Architecture-x64-orange?style=for-the-badge" alt="Architecture x64">
</p>

<p align="center">
  <a href="#-key-features">Key Features</a> •
  <a href="#-functional-overview">Functional Overview</a> •
  <a href="#-core-architecture--mechanisms">Core Mechanisms</a> •
  <a href="#-quick-start">Quick Start</a> •
  <a href="#-command-line-interface-cli">CLI Support</a> •
  <a href="#-verified-versions--cryptographic-fingerprints">Verified Versions</a> •
  <a href="#-project-structure">Project Structure</a> •
  <a href="#-open-source-license">License</a> •
  <a href="#-disclaimer">Disclaimer</a>
</p>

---

## 🌟 Key Features

- 🚀 **Zero External Dependencies · Native Toolchain Execution**  
  No heavyweight .NET SDK, Visual Studio, or runtime prerequisites required. Compiles within milliseconds using the built-in Windows native C# compiler (`csc.exe`), producing a standalone executable of approximately 240 KB.
- 🎨 **Code-First Modern WPF Interface**  
  Constructed entirely in pure C# code without any XAML overhead. Integrates native Windows Desktop Window Manager (DWM) immersive dark-mode titlebars and built-in Per-Monitor High-DPI dynamic scaling.
- 🛡️ **Byte-Level Preflight Safety Gating**  
  Validates both structural PE headers and redundant expected byte sequences prior to any modification. Aborts immediately with a zero-byte-written fail-closed guarantee upon any fingerprint or layout mismatch.
- 💾 **Version-Aware Atomic Backup & Restoration**  
  Automatically archives clean original binaries to `IDMan.exe.BAK`. Inspects embedded version metadata to detect stale backups from past updates, preventing rollback version misalignment.
- ⚡ **Multi-Paradigm Activation Strategies**  
  Consolidates deep binary patching, Windows ACL registry evaluation freezing, and personalized identity registration into a single modular solution.

---

## 📋 Functional Overview

### 1. Core Operating Modes

| Mode | Underlying Mechanism | Recommended Scenario |
| :--- | :--- | :--- |
| 🔥 **Mode 1: Rapid Deep Unlock** | Scans and patches 15 instruction sites (31 bytes) in `IDMan.exe` using AOB dual-state signatures (including 1 version-adaptive optional site), strips Authenticode certificates, recomputes the PE checksum, and writes permanent license metadata. | Complete offline entitlement with all functional and dialog restrictions removed. |
| ❄️ **Mode 2: Permanent Trial Freeze** | Employs Windows Access Control Lists (ACLs) to write-protect IDM's evaluation CLSID registry keys and timestamps at a fixed 30-day trial status without altering binary code. | Users requiring unaltered PE binary hashes and compatibility with silent official in-app updates. |
| 💎 **Mode 3: Custom Identity Registration** | Injects custom user name and email credentials (with randomized identity generation) into the registry while coordinating underlying binary unlock hooks. | Customizing personalized registered ownership displays in the IDM interface. |
| 🔄 **Mode 4: Factory Reset & State Cleanup** | Purges evaluation CLSID registry markers, known blacklist records, telemetry flags, and leftover state, restoring IDM to a clean post-installation state. | Resolving corrupted state, notification anomalies, or preparing for clean testing. |
| ♻️ **One-Click Official Restore** | Restores the unpatched binary from `IDMan.exe.BAK`, strips registration keys, and returns IDM to an unactivated trial state. | Quick, zero-side-effect rollback to stock condition. |

### 2. Security Shields & Maintenance Utilities

- **🛡️ Hosts Loopback Shield**: Intelligently toggles `127.0.0.1` loopback mappings in the Windows `hosts` file for 8 primary verification servers (e.g., `tonec.com`, `registeridm.com`), severing network-layer telemetry and serial blacklisting.
- **⚙️ Official Update Policy Control**: Toggles the `CheckUpdtVM` registry policy to silence automated update prompts or re-enable them on demand.
- **🧰 Registry & Path Utilities**:
  - **📍 Custom IDM Path Resolution**: Full support for non-system drives (D:\, E:\, etc.) and portable installations with automatic polling, interactive file selection dialogs, and persistent configuration memory.
  - One-click navigation to the IDM installation directory.
  - One-click launch and deep-navigation to `HKEY_CURRENT_USER\Software\DownloadManager` in Windows Registry Editor.
  - Complete one-click registry configuration export to the desktop (`IDM_Reg_Backup.reg`).
- **⚡ Process Control**: Safe single-click termination, execution, and restart of the IDM core process.

---

## 🔬 Core Architecture & Mechanisms

```
[Stock IDMan.exe] ──> [PE Structural Integrity Check] ──> [AOB Dual-State Signature Scan]
                               │
                               ├──> 1. AOB Signature Scan & Patch (15 sites / 31 bytes)
                               ├──> 2. Zero Authenticode Directory & Truncate 10,608-byte Overlay
                               ├──> 3. Standard PE Checksum Recomputation (Microsoft Algorithm)
                               ├──> 4. Pre/Post-Write Dual PE Validation with Atomic Rollback
                               └──> 5. Purge Counterfeit Serial & Register Valid Entitlement
```

### 0. AOB Pattern Signature Scanning Engine (v3 Architecture Core)

Legacy solutions (v2 and earlier) relied on **hardcoded file offsets**. Each minor IDM maintenance release involves full re-compilation, inducing **non-uniform code relocations** (e.g., shifts ranging non-linearly from −896 to +64 bytes between 6.43 build 10 and build 11). Fixed offsets inevitably corrupt executable code sections, triggering fatal Win32 errors such as `0x80004005: The specified executable is not a valid application for this OS platform`.

The **v3 architecture** transitions to an **Array of Bytes (AOB) Pattern Signature Scanning Engine**:

1. Each patch target defines both **Pristine** (`SigOriginal`) and **Patched** (`SigPatched`) byte signatures.
2. The engine scans for `SigPatched` first to ensure seamless idempotency across multiple runs.
3. Signatures require **strict unique matching** across the entire binary image, coupled with redundant `Expected` byte checks at the computed relative offset.
4. If **any required site** fails to match, the engine aborts with zero disk modifications.
5. Signatures are derived from **cross-version common invariant regions**, filtering out compiler-generated relocation pointers.

> Current signatures are validated across **IDM 6.43 build 10**, **6.43 build 11 (6.43.11.2)**, and **6.43 build 11 (6.43.11.3)**.  
> The **14 primary sites** match uniquely across all three versions.  
> The **15th site** is an optional version-adaptive patch specifically targeting build 11.3 anti-piracy behavior (see §0.2).

### 0.1 Version-Aware Backup Mechanism (Preventing Stale Rollback Points)

When a user updates IDM, an existing `IDMan.exe.BAK` in the target directory often contains the stock binary of the **previous version**. Unconditionally reusing this file leads to version skew:
- Rollback snapshots point to an outdated release.
- Restoring the backup overwrites the updated installation with obsolete binaries, creating runtime DLL interface mismatches.

This toolkit enforces a **Version-Aware Backup Protocol**:

| Scenario | Engine Action |
| :--- | :--- |
| `BAK` missing | Creates backup immediately from current binary. |
| `BAK` version == Current version | Preserves existing backup without modification. |
| `BAK` version ≠ Current version & Current binary is pristine | Archives outdated backup to `IDMan.exe.BAK.<oldVer>` and captures clean backup of new release. |
| `BAK` version ≠ Current version & Current binary is already modified | **Refuses to overwrite backup**, protecting user rollback safety. |

Additionally, the restoration module enforces a **Version Consistency Guard**, rejecting restore operations if the backup version differs from installed companion components.

### 0.2 Optional-Site Mechanism (Version-Adaptive Patching)

Certain anti-piracy branches only exist in specific compiler builds (e.g., defensive checks introduced in newer maintenance revisions). Requiring unanimous matching across all points causes the engine to falsely reject legacy releases.

Version 1.4.0 introduces the `AobPoint.Optional` flag:

| Site Classification | Pattern Found | Pattern Not Found |
| :--- | :--- | :--- |
| **Required Site** | Patches binary. | **Aborts operation with zero disk writes.** |
| **Optional Site** | Patches binary. | Logs informational message and **continues without error**. |

Preflight gating requires that all required sites are satisfied: `requiredOk == requiredCount`.

**Multi-Version Adaptability Matrix**:

| Release Target | Matched Sites | Resulting Binary Hash |
| :--- | :--- | :--- |
| **build 10** | 14 / 15 (Optional skipped) | Identical to v1.3.0 (`712BD0D9…`) — Zero Regression |
| **build 11 (11.2)** | 14 / 15 (Optional skipped) | Identical to v1.3.0 (`3470B5B8…`) — Zero Regression |
| **build 11 (11.3)** | **15 / 15** | Applies 15th site patch (`641A6D97…`), neutralizing registration dialogs |

---

### 1. Dual-Layer Defense: Registry Strategy & Binary Branch Override

IDM performs asymmetric cryptographic signature checks on the `Serial` registry value. Supplying an arbitrary or synthetic serial triggers counterfeit detection alarms.

**Registry Layer (Policy Surface)**:
1. **Purge** the `Serial` key to bypass public-key validation routines.
2. Clean telemetry tracking keys: `scansk`, `tvfrdt`, `radxcnt`, `ptrk_scdt`, `LastCheckQU`, `scTime`, `NextCheck`, `BList`, `md5pks`.
3. Populate identity keys: `FName`, `LName`, and `Email`.

> ⚠️ **Key Insight (v1.4.0)**: **Deleting `Serial` alone is insufficient in build 11.3**.  
> Build 11.3 introduced a defensive check: **if the `Serial` key is absent on launch, IDM immediately forces the registration modal dialog** (Dialog Resource ID 138).  
> Version 1.4.0 adds Site #15 at the binary decision level (`je` → `jmp`), forcing execution down the "Serial present and verified" path, establishing a **dual-layer defense**.  
>  
> *Architectural Principle*: Registry keys represent a volatile policy surface subject to vendor modification; binary conditional branches represent the invariant decision surface.

### 2. Authenticode Stripping & PE Checksum Normalization

Patching code sections invalidates the official Authenticode digital signature, causing security subsystems to flag the executable as tampered.  
This toolkit parses the PE image dynamically:
- Clears `VirtualAddress` and `Size` in `IMAGE_DIRECTORY_ENTRY_SECURITY` (Data Directory index 4).
- Truncates the physical 10,608-byte digital certificate block appended to the file overlay (e.g., resizing build 11.3 from 6,200,176 to exactly 6,189,568 bytes, matching `pe.ImageEnd`).
- Recomputes the PE Checksum using the standard Microsoft folding addition algorithm, restoring binary structural compliance.

---

## 🚀 Quick Start

### Method 1: Pre-Compiled Release Binary

1. Download the latest archive from the [Releases Page](https://github.com/angusdevgo/IDM_Pro_Tool/releases).
2. Extract the archive, ensuring `app_icon.png` resides alongside `IDM_Pro_Tool.exe`.
3. Right-click `IDM_Pro_Tool.exe` and select **Run as administrator**.
4. Select your desired mode from the interface and click execute.

### Method 2: Compile from Source

Compiles natively on any modern Windows environment (Windows 10 / 11 includes .NET Framework 4.x out of the box). Clone the repository and run `build.bat`:

```powershell
# 1. Clone the repository
git clone https://github.com/angusdevgo/IDM_Pro_Tool.git
cd IDM_Pro_Tool

# 2. Execute the native build script
.\build.bat
```

> **Build Details**: `build.bat` invokes `%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe` directly, completing compilation in 1–2 seconds with zero toolchain overhead.

---

## 💻 Command Line Interface (CLI)

The toolkit features full headless command-line support for automation scripts, unattended deployments, and CI/CD pipelines:

```powershell
# Execute Mode 1: Rapid Deep Unlock (AOB binary patch + registration)
IDM_Pro_Tool.exe -patch

# Execute Mode 2: Permanent Trial Freeze (Windows ACL evaluation lock)
IDM_Pro_Tool.exe -freeze

# Execute Mode 3: Custom Identity Registration
IDM_Pro_Tool.exe -register "VIP_User" "vip@domain.com"

# Revert to clean stock installation from BAK
IDM_Pro_Tool.exe -restore

# Explicitly configure and persist custom IDM installation path
IDM_Pro_Tool.exe -setpath "D:\Software\Internet Download Manager"

# Display CLI help documentation
IDM_Pro_Tool.exe -help
```

---

## 📂 Project Structure

```text
IDM_Pro_Tool/
├── src/
│   ├── Program.cs          # Unified source (~3000 lines, code-first WPF vector UI & patch engines)
│   ├── app.ico             # Multi-resolution application icon asset (16–256px)
│   ├── app_icon.png        # 256x256 high-resolution vector interface asset
│   └── app.manifest        # Windows UAC execution level & Per-Monitor DPI awareness manifest
├── tests/
│   ├── PatchEngineTests.cs # Automated regression harness (61 assertions across all versions)
│   ├── QuickPatch.cs       # Minimal engine CLI harness for rapid validation
│   ├── build_tests.bat     # Regression harness build script
│   └── build_quick.bat     # Standalone driver build script
├── build.bat               # Native batch compilation and asset assembly script
├── IDM_Pro_Tool.exe        # Compiled x64 Windows GUI application
├── app_icon.png            # Runtime window icon dependency
├── LICENSE                 # GNU General Public License v3.0
├── README.md               # English documentation (Default)
└── README.zh.md            # Simplified Chinese documentation
```

---

## 🔍 Verified Versions & Cryptographic Fingerprints

This toolkit is rigorously tested against official retail distribution binaries:

| Verification Item | IDM 6.43 build 10 | IDM 6.43 build 11 (6.43.11.2) | IDM 6.43 build 11 (6.43.11.3) |
| :--- | :--- | :--- | :--- |
| **Product Version** | `IDMan.exe` v6.43.10.2 | v6.43.11.2 | v6.43.11.3 |
| **Stock File Size** | 6,199,664 bytes | 6,200,176 bytes | 6,200,176 bytes |
| **Stock SHA-256** | `03CC62E9…D16D607C` | `E8B0459D…9AB9DD4E69` | `D0993EC0…7CDB194C6A` |
| **Stock PE Checksum** | `0x005ECD00` | `0x005EF1D7` | `0x005E9C44` |
| **Patched File Size** | 6,189,056 bytes | 6,189,568 bytes | 6,189,568 bytes |
| **Patched SHA-256 (v1.3.0)** | `712BD0D9…36FCC79CC6` | `3470B5B8…DEA6CD601D8` | `F4CF6939…20F920A5F4` |
| **Patched Checksum (v1.3.0)** | `0x005EBDA3` | `0x005E84FA` | `0x005F4B5D` |
| **Patched SHA-256 (v1.4.0)** | `712BD0D9…36FCC79CC6` | `3470B5B8…DEA6CD601D8` | `641A6D97…B6CC404763E` |
| **Patched Checksum (v1.4.0)** | `0x005EBDA3` | `0x005E84FA` | `0x005EC25E` |

> *Note on Historical Hashes*: Legacy crack releases (e.g. v20.7) populated the PE checksum field with `0x005F0BEA`. Exhaustive algorithmic analysis proves this value corresponds to no valid Microsoft checksum standard. This toolkit writes the **mathematically valid standard checksum**.

> *Signature Invariance*: AOB patterns are anchored in multi-version invariant byte sequences, naturally immune to relocation noise. The 14 core sites match uniquely across all tested releases; Site #15 automatically activates on build 11.3+ via the `Optional` subsystem.

---

## ⚠️ Disclaimer

1. This project, including all associated source code and compiled executables, is provided **strictly for reverse engineering, Windows operating system internals, PE file structure analysis, and educational security research**.
2. Users should delete all downloaded files within 24 hours of testing. Commercial use or unauthorized redistribution is strictly prohibited.
3. If you regularly use Internet Download Manager, please support software developers by purchasing an official license at the [Official IDM Website](https://www.internetdownloadmanager.com/).
4. The author assumes no liability for software conflicts, data loss, or system instability arising from the use of this software.

---

## 📄 Open Source License

This project is licensed under the **[GNU General Public License v3.0](LICENSE)** (GPL-3.0).

### Permissions

- ✅ **Commercial Use** — May be used for any purpose, including commercial endeavors.
- ✅ **Modification** — Full freedom to inspect, research, and alter source code.
- ✅ **Distribution** — Freedom to copy, share, and redistribute.
- ✅ **Patent Grant** — Express patent grant from contributors.

### Conditions & Obligations

- 📌 **Copyleft (Reciprocal License)** — Any modified or derivative works **must also be released under GPL-3.0** with full source code made available.
- 📌 **License and Copyright Notice** — Original copyright headers and license text must be preserved in all copies.
- 📌 **State Changes** — Modified files must carry prominent notices documenting that changes were made.
- 📌 **No Additional Restrictions** — Downstream distributors may not place terms that restrict freedoms granted by GPL-3.0.

### Warranty Disclaimer

- ⚠️ **No Warranty** — The software is provided "AS IS", without warranty of any kind, express or implied.
- ⚠️ **Research Purpose** — Please consult the Disclaimer above; do not use for copyright infringement.

For full terms and conditions, consult the [LICENSE](LICENSE) file or visit <https://www.gnu.org/licenses/gpl-3.0.html>.

Issues and Pull Requests are welcome!

---

## 🤝 Community & Acknowledgements

- **LINUX DO Community**: [https://linux.do](https://linux.do)

---

## ⭐ Star History

<a href="https://star-history.com/#angusdevgo/IDM_Pro_Tool&Date">
 <picture>
   <source media="(prefers-color-scheme: dark)" srcset="https://api.star-history.com/svg?repos=angusdevgo/IDM_Pro_Tool&type=Date&theme=dark" />
   <source media="(prefers-color-scheme: light)" srcset="https://api.star-history.com/svg?repos=angusdevgo/IDM_Pro_Tool&type=Date" />
   <img alt="Star History Chart" src="https://api.star-history.com/svg?repos=angusdevgo/IDM_Pro_Tool&type=Date" />
 </picture>
</a>
